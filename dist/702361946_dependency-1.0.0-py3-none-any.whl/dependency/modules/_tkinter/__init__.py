#  Copyright (c) 2025.
#  702361946@qq.com(https://github.com/702361946)

from ._component import *

__varsion__ = "0.1.0"
__author__ = "702361946@qq.com"
__license__ = "MIT"
__all__ = [
    "Window",
    "TKComponent",
    "__varsion__",
    "__author__",
    "__license__"
]
