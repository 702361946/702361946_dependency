from ._SQLite3 import SQLite

__version__ = "1.0"
__author__ = "702361946@qq.com"
__license__ = "MIT"
__all__ = [
    "SQLite"
]
